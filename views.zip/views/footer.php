<footer class="container-fluid">
    <div class="row">

        <div class='col-sm-8'>
            <img class="img-responsive" src="img/igp.png" alt="igp.png" />
            <img class="img-responsive" src="img/rdc.png" alt="rdc.png" />
        </div>
        <div class='col-sm-4'>
            <nav class="navbar navbar-expand" role="navigation">
                <ul class="nav navbar-nav">
                    <li><a href="index.php" class="btn btn-form" role="button">Accueil</a></li>
                    <li><a href="reglement.php" class="btn btn-form" role="button">Règlement</a></li>
                    <li><a href="contact.php" class="btn btn-form" role="button">Contact</a></li>
                </ul>
            </nav>             
        </div>
    </div>
</footer>
</body>
<script src="Js/script.js" type="text/javascript"></script>
<script type="text/javascript" src="jqscript.js"></script>

</html>